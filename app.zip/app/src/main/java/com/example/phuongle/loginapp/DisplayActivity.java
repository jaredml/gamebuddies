package com.example.phuongle.loginapp;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by PHUONG LE on 4/25/2016.
 */
public class DisplayActivity extends AppCompatActivity{
}
