package com.example.phuongle.loginapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by PHUONG LE on 4/20/2016.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "GAME_BUDDIES.db";


    private static final String TABLE_USER = "User";
    private static final String KEY_NAME = "username";
    private static final String EMAIL = "email";
    private static final String PASSWORD = "password";


    private static final String TABLE_PROFILE = "Profile";
    private static final String FKEY_NAME = "p_username";
    private static final String GAMEPREF = "gamepreference";
    private static final String ABOUT = "about";
    private static final String AGE = "age";
    private static final String REGION = "region";
    private static final String RATING = "rating";


    private static final String TABLE_GAME = "Game";
    private static final String GAME_NAME = "g_name";
    private static final String GAME_GENRE = "g_genre";

    private static final String TABLE_REGION = "Region";
    private static final String REGION_NAME = "r_name";



    public DatabaseHelper(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }

    SQLiteDatabase db;
    @Override
    public void onCreate(SQLiteDatabase db) {
        this.db = db;
        db.execSQL("CREATE TABLE " + TABLE_USER + "(username String PRIMARY KEY, email String, password String);");
        db.execSQL("CREATE TABLE " + TABLE_PROFILE + "(p_username String, gamepreference String, about String, age int, region string, rating double, FOREIGN KEY (p_username) REFERENCES " + TABLE_USER + "(username));");
        db.execSQL("CREATE TABLE " + TABLE_GAME + " (g_name String, genre String);");
        db.execSQL("CREATE TABLE " + TABLE_REGION + " (r_name String);");
    }



    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PROFILE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GAME);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_REGION);
        this.onCreate(db);
    }

    public boolean insertDataRegister(String name, String email, String password)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(KEY_NAME, name);
        contentValues.put(EMAIL, email);
        contentValues.put(PASSWORD, password);


        long result = db.insert(TABLE_USER, null, contentValues);
        if(result == -1)
            return false;
        else return true;

    }

    public String searchPass(String username)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "select username, password from "+TABLE_USER;
        Cursor  cursor = db.rawQuery(query, null);
        String a, b;
        b = "not found";
        if(cursor.moveToFirst())
        {
            do{
                a = cursor.getString(0);
                if(a.equals(username))
                {
                    b = cursor.getString(1);
                    break;
                }
            }while(cursor.moveToNext());
        }
        return b;
    }

    public Cursor DisplayProfile()
    {

        db = this.getReadableDatabase();
        String query = "select * from " + TABLE_PROFILE;
        Cursor  cursor = db.rawQuery(query, null);
        return cursor;

    }


}
