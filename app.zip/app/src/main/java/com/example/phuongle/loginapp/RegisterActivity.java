package com.example.phuongle.loginapp;
import java.sql.*;

import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.preference.DialogPreference;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
    DatabaseHelper mydb;
    EditText Name, Email, Password, ConPass;
    Button reg_button;
    AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mydb = new DatabaseHelper(this);
        Name = (EditText) findViewById(R.id.reg_name);
        Email = (EditText) findViewById(R.id.reg_email);
        Password = (EditText) findViewById(R.id.reg_password);
        ConPass = (EditText) findViewById(R.id.reg_con_password);
        reg_button = (Button) findViewById(R.id.reg_button);
        //Register();

        String namein = Name.getText().toString();
        String emailin = Email.getText().toString();
        String passwordin = Password.getText().toString();
        String confirmpass = ConPass.getText().toString();
        Register();
    }



    public void Register() {
        reg_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String namein = Name.getText().toString();
                String emailin = Email.getText().toString();
                String passwordin = Password.getText().toString();
                String confirmpass = ConPass.getText().toString();

                if (Name.getText().toString().equals("") || Email.getText().toString().equals("") || Password.getText().toString().equals("")) {
                    builder = new AlertDialog.Builder(RegisterActivity.this);
                    builder.setTitle("Something went wrong...");
                    builder.setMessage("Please fill all the field...");
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which)
                        {
                            dialog.dismiss();
                        }
                    });
                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }
                else if (!Password.getText().toString().equals(ConPass.getText().toString())) {
                    builder = new AlertDialog.Builder(RegisterActivity.this);
                    builder.setTitle("Something went wrong...");
                    builder.setMessage("Password does not match");
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            Password.setText("");
                            ConPass.setText("");
                        }
                    });
                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }



                else {
                    //BackgroundTask backgroundTask = new BackgroundTask(RegisterActivity.this);
                   // backgroundTask.execute("register",Name.getText().toString(), Email.getText().toString(),Password.getText().toString());
                    User u = new User();
                    u.setUsername(namein);
                    u.setEmail(emailin);
                    u.setPassword(passwordin);

                   // mydb.insertDataRegister(u);



                    boolean isInserted = mydb.insertDataRegister(u);
                    if(isInserted = true)
                        Toast.makeText(RegisterActivity.this, "Register Success", Toast.LENGTH_LONG).show();
                    else
                        Toast.makeText(RegisterActivity.this, "Register Failed", Toast.LENGTH_LONG).show();

                }
            }
        });
    }
}



